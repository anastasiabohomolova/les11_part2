from django.contrib import messages
from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse, HttpResponseRedirect
from shop.models import Shoping
from shop.forms import ShopingForm



def shop_page(request):
    queryset = Shoping.objects.all()
    context = {
        'title': 'Shop',
        'objects_list': queryset
    }

    return render(request, 'home.html', context)

def detail_page(request, id=None):
    instance = get_object_or_404(Shoping, id=id)
    context = {
        'title': 'Detail',
        'object': instance
    }

    return render(request, 'detail_page.html', context)

def page_category(request):
    return render(request, 'category_page.html')

def page_dresses(request):
    queryset = Shoping.objects.filter(type="dresses")
    context = {
        'title': 'Dresses',
        'objects_closes': queryset
    }

    return render(request, 'obj_closes.html', context)

def page_bags(request):
    queryset = Shoping.objects.filter(type="bags")
    context = {
        'title': 'Bags',
        'objects_closes': queryset
    }

    return render(request, 'obj_closes.html', context)

def page_suits(request):
    queryset = Shoping.objects.filter(type="suits")
    context = {
        'title': 'Suits',
        'objects_closes': queryset
    }

    return render(request, 'obj_closes.html', context)

def create_closes(request):
    form = ShopingForm(request.POST or None)
    if form.is_valid():
        instance = form.save(commit=False)
        instance.save()
        messages.success(request, '<a href="/shop/">Closes</a> created!', extra_tags='html_safe')
        return HttpResponseRedirect(instance.get_url_category())
    context = {
        'title': 'Create closes',
        'form': form
    }
    return render(request, 'create_closes.html', context)

def update_closes(request, id=None):
    instance = get_object_or_404(Shoping, id=id)
    form = ShopingForm(request.POST or None, instance=instance)
    if form.is_valid():
        instance = form.save(commit=False)
        instance.save()
        messages.success(request, '<a href="/shop/create/">Closes</a> update!', extra_tags='html_safe')
        return HttpResponseRedirect(instance.get_url_category())

    context = {
        'title': 'Update closes',
        'form': form
    }

    return render(request, 'create_closes.html', context)

def delete_closes(request, id=None):
    instance = get_object_or_404(Shoping, id=id)
    instance.delete()
    return redirect('shop:shop_page')

















