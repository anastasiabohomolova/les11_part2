from django import forms
from shop.models import Shoping


class ShopingForm(forms.ModelForm):
    class Meta:
        model = Shoping
        fields = [
            'name',
            'price',
            'way',
            'type'
        ]